package revision2;

import java.sql.*;

//CODING BAGI CONNECTION DENGAN DATABASE
public class FrameRev2 extends javax.swing.JFrame {
Connection cnc = null;
Statement st = null;
ResultSet rs = null;

    public FrameRev2() throws SQLException {
        initComponents();
        setTitle("TAJUK SYSTEM KAT SINI");
        cnc = getSambungan();
        st = cnc.createStatement();
    }
    
    public Connection getSambungan() {
    try {
    Class.forName("com.mysql.jdbc.Driver");
    cnc = DriverManager.getConnection("jdbc:mysql:///revision2","root","");
    }
    
    catch(Exception ex){
    ex.printStackTrace();
    }    
    
    return cnc;
    }