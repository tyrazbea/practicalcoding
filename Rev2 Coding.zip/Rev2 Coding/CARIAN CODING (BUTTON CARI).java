    private void BtnCariActionPerformed(java.awt.event.ActionEvent evt) {                                        
    //copy dari sini
    String sqlCari = "SELECT * FROM `information` WHERE Nama = '"+txtCari.getText()+"' ";
    
    try {
    rs = st.executeQuery(sqlCari);
    rs.last();
    int kiraRow = rs.getRow();
    
    if (kiraRow > 0) {
    JOptionPane.showMessageDialog(null, "Telah Dijumpai");
    txtNama.setText(rs.getString(2)); //kenapa mula dari no2? sbb no1 utk id
    txtUmur.setText(rs.getString(3));
    txtFav.setText(rs.getString(4));
    }
    
        else {
        JOptionPane.showMessageDialog(null, "Data x Dijumpai");
        }
    }
    
    catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, ex);
    } // sampai sini
    }   