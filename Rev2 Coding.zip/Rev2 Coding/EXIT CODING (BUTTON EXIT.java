    private void BtnExitActionPerformed(java.awt.event.ActionEvent evt) {                                        
    //copy nie je "System.exit(0);"
    System.exit(0);
    }    