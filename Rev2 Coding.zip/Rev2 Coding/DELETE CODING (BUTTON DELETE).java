    private void BtnDeleteActionPerformed(java.awt.event.ActionEvent evt) {                                          
    //copy dari sini
    String sqlDelete = "DELETE FROM `information` WHERE Nama = '"+txtNama.getText()+"' ";
    
    try {
    st.executeUpdate(sqlDelete);
    int q=st.executeUpdate(sqlDelete);
    if (q == 0) {
    JOptionPane.showMessageDialog(null, "Data telah Di-Delete");
    }
    
        else {
        JOptionPane.showMessageDialog(null, "Data tidak Berjaya Dibuang");
        }
    }
    
    catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, ex);
    } //copy sampai sini
    }                                         
