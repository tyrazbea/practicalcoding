    private void BtnAddActionPerformed(java.awt.event.ActionEvent evt) {                                       
    //copy sini
	String sqlAdd = "INSERT INTO `information`(`Nama`, `Umur`, `M_Favourite`) VALUES ('"+txtNama.getText()+"','"+txtUmur.getText()+"','"+txtFav.getText()+"')";
    
    try {
    int q;
    q = st.executeUpdate(sqlAdd);
    if(q > 0) {
    JOptionPane.showMessageDialog(null, "Kemasukan Data Berjaya");
    }
    
        else {
        JOptionPane.showMessageDialog(null, "Kemasukan Data x Berjaya");
        }
    }
    
    catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, ex);
    }
	//sampai sini
    }  