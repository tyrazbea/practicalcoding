    private void BtnEditActionPerformed(java.awt.event.ActionEvent evt) {                                        
    //copy dari sini
    String sqlEdit = "UPDATE `information` SET `Nama`='"+txtNama.getText()+"',`Umur`='"+txtUmur.getText()+"',`M_Favourite`= '"+txtFav.getText()+"' WHERE Nama = '"+txtNama.getText()+"' ";
    
    try {
    int q;
    q = st.executeUpdate(sqlEdit);
    if (q > 0) {
    JOptionPane.showMessageDialog(null, "Data Berjaya Di-UPDATE");
    }
    
        else {
        JOptionPane.showMessageDialog(null, "Data tidak berjaya Di-Update");
        }
    }
    
    catch (SQLException ex){
    JOptionPane.showMessageDialog(null, ex);
    }   //sampai sini    
    }   