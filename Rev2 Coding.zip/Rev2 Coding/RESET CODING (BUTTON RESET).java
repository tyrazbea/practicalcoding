    private void BtnResetActionPerformed(java.awt.event.ActionEvent evt) {                                         
    //copy dari sini
    txtNama.setText("");
    txtUmur.setText("");
    txtFav.setText("");
    //sampai sini
    }  